#ifndef GINT_KEYBOARD_STUB_H
#define GINT_KEYBOARD_STUB_H
typedef struct { int key; } key_event_t;
enum {
 KEY_0=100,KEY_1,KEY_2,KEY_3,KEY_4,KEY_5,KEY_6,KEY_7,KEY_8,KEY_9,
 KEY_UP,KEY_DOWN,KEY_EXE,KEY_EXIT,KEY_MENU,KEY_F1,KEY_F2,KEY_F3,KEY_F4,KEY_F5,KEY_F6,
 KEY_NEG,KEY_SUB,KEY_DEL,KEY_ACON,KEY_LPAR,KEY_RPAR
};
static inline key_event_t getkey(void){ key_event_t e={KEY_EXIT}; return e; }
#endif
