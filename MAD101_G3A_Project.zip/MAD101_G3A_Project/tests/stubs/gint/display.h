#ifndef GINT_DISPLAY_STUB_H
#define GINT_DISPLAY_STUB_H
#define DWIDTH 384
#define DHEIGHT 216
#define C_WHITE 0xffff
#define C_BLACK 0x0000
static inline void dclear(int c){(void)c;}
static inline void dtext(int x,int y,int c,const char*s){(void)x;(void)y;(void)c;(void)s;}
static inline void dline(int x1,int y1,int x2,int y2,int c){(void)x1;(void)y1;(void)x2;(void)y2;(void)c;}
static inline void dupdate(void){}
#endif
