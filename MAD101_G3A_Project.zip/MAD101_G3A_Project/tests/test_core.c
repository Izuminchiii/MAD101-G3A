#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../src/core.h"
#include "../src/logic.h"

int main(void)
{
    assert(mad_gcd(899,941)==1);
    assert(mad_gcd(25,13)==1);
    int64_t q,r; mad_floor_divmod(-124,15,&q,&r); assert(q==-9 && r==11);
    mad_floor_divmod(-107,15,&q,&r); assert(q==-8 && r==13);
    assert(mad_divisor_count(120)==16);
    assert(mad_lcg_term(1,3,4,7,3)==2);
    assert(mad_lcg_term(3,5,4,7,4)==0);
    int ov=0;
    assert(mad_combination(12,3,&ov)==220 && !ov);
    assert(mad_permutation(12,3,&ov)==1320 && !ov);
    assert(mad_count_injections(5,4,&ov)==0);
    assert(mad_inclusion_two(200,5,7)==63);
    int v,l,i;
    assert(mad_full_mary_from_vertices(2,61,&i,&l) && i==30 && l==31);
    assert(mad_full_mary_from_leaves(3,101,&i,&v) && i==50 && v==151);
    int d1[]={3,3,3,3,2}; assert(mad_is_graphical(d1,5));
    int d2[]={1,2,3,4,4}; assert(!mad_is_graphical(d2,5));
    assert(mad_euler_type((int[]){2,2,2},3)==2);
    assert(mad_euler_type((int[]){1,2,1},3)==1);
    int a[]={7,2,4,3,1,6,5}; mad_insertion_sort_prefix(a,7,3);
    int expected[]={2,3,4,7,1,6,5}; assert(memcmp(a,expected,sizeof(a))==0);
    int64_t out; assert(mad_eval_prefix("- ^ + 2 3 3 2",&out) && out==123);
    assert(mad_eval_postfix("2 3 + 3 ^ 2 -",&out) && out==123);
    MadLogicResult lr=mad_logic_eval("(PIQ)AR",0,0,1); assert(lr.valid && lr.value==1);
    assert(mad_logic_classify("(PAQ)I(PIQ)")==2);
    assert(mad_logic_equivalent("PIQ","NPOQ")==1);
    int matrix[]={1,2,0,2,0,2,0,2,2};
    int64_t walks=0; assert(mad_walk_count(matrix,3,3,1,2,&walks));
    printf("walks=%lld\n",(long long)walks);
    printf("All tests passed.\n");
    return 0;
}
