from pathlib import Path

Q=[]
def add(cat,q,a,b,c,d,ans,exp):
    Q.append((cat,q,[a,b,c,d],ans,exp))

# LOGIC
add('Logic','For (p I q) A r to be true, which assignment works?','p=T q=F r=T','p=F q=F r=F','p=F q=T r=F','p=F q=F r=T',3,'p I q is true when p is false; r must also be true.')
add('Logic','"Neither p nor q" is represented by:','N(p O q)','N(p A q)','Np O q','p O Nq',0,'By De Morgan, neither p nor q means not(p or q).')
add('Logic','Which is always true? (p A q) I (p I q)','Always true','Always false','Only when p=T','Only when q=F',0,'If p and q are true, p implies q is true; otherwise implication premise is false.')
add('Logic','Is (p O q) I (p I q) a tautology?','Yes','No','Only if p=q','Only if q=T',1,'Counterexample p=T,q=F makes premise true and conclusion false.')
add('Logic','Some student plays badminton or knows Java, possibly both:','Ex(Cx A (Px O Jx))','Ex(Cx I (Px O Jx))','Ax(Cx I (Px X Jx))','Ax(Cx A (Px O Jx))',0,'"Some" uses exists; the person must be a student and satisfy inclusive OR.')
add('Logic','All students do exactly one of badminton or Java:','Ax(Cx I (Px X Jx))','Ax(Cx A (Px X Jx))','Ex(Cx I (Px O Jx))','Ax(Cx I (Px O Jx))',0,'All people: if a person is a student, then XOR holds.')
add('Logic','Every student knows some programming language:','Ax Ey(Px I Qxy)','Ey Ax(Px I Qxy)','Ax Ey(Px A Qxy)','Ey Ax(Px A Qxy)',0,'For every person x, if x is a student, some language y is known by x.')
add('Logic','"Exactly one person is fooled by everybody" needs:','Existence only','Uniqueness only','Existence and uniqueness','Universal x only',2,'Exactly one combines an existence clause with a uniqueness clause.')
add('Logic','Over positive integers, Ax(x^2>x) is:','True','False','Undefined','A tautology',1,'x=1 gives 1>1, which is false.')
add('Logic','Over positive integers, Ax(|x|>0) is:','True','False','Only for even x','Only for x>1',0,'Every positive integer has positive absolute value.')
add('Logic','Negation of Ex Ey(Fxy A Az Lyz) starts with:','Ex Ey','Ax Ay','Ex Ay','Ax Ey',1,'Negating existential quantifiers changes both to universal.')
add('Logic','Negation of A A is formed by:','Keep A and change AND to OR','Change A to E and negate inside','Change A to E only','Negate variables only',1,'Quantifier negation: not forall becomes exists, then negate the predicate.')
add('Logic','From p I q and not q, conclude not p. This is:','Modus ponens','Modus tollens','Affirming consequent','Simplification',1,'Modus tollens uses p->q and not q to infer not p.')
add('Logic','From p I q and q, concluding p is:','Valid','Modus tollens','Affirming the consequent','Disjunctive syllogism',2,'The conclusion does not follow; q may be true for another reason.')
add('Logic','From p I q and not p, concluding not q is:','Valid','Denying the antecedent','Modus ponens','Resolution',1,'This is the invalid fallacy of denying the antecedent.')
add('Logic','(p I q) O (Np I q) simplifies to:','p','q','T','F',2,'One of p or not p holds, so at least one implication is true.')
add('Logic','The truth pattern T,F,T,F for rows TT,TF,FT,FF is:','p','q','p X q','p B q',1,'q is true exactly in rows where the second variable is true.')
add('Logic','p I q is equivalent to:','p O q','Np O q','p A Nq','Np A q',1,'Implication law: p->q equals not p or q.')
add('Logic','Negation of p A q equals:','Np A Nq','Np O Nq','p O q','p X q',1,'De Morgan law changes AND to OR and negates both parts.')
add('Logic','p B q is true when:','Exactly one is true','Both have the same value','p is true','q is false',1,'Biconditional means both propositions have equal truth values.')

# SETS/FUNCTIONS
add('Sets','If |A|=x, |B|=x+1 and |A x B|=90, find x.','8','9','10','12',1,'x(x+1)=90, so x=9.')
add('Sets','Power set size of a 5-element set is:','5','10','25','32',3,'A set with n elements has 2^n subsets.')
add('Sets','P({empty,a}) contains how many elements?','2','3','4','8',2,'The original set has two distinct elements, so its power set has 4 subsets.')
add('Sets','X={1,2,3,4,5}, Y={0,3,6,9}. Smallest set is:','X intersect Y','X-Y','Y-X','X union Y',0,'Intersection is {3}, cardinality 1.')
add('Sets','U={a,b,c,d,e,f,g,h,i,j}; subset {a,c,d,g,h,j} bit string:','1011001101','1011001110','1011011110','1011001011',0,'Write 1 at positions a,c,d,g,h,j.')
add('Sets','For bit strings, union corresponds to:','AND','OR','XOR','NOT',1,'An element is in the union when either input bit is 1.')
add('Sets','Symmetric difference corresponds to:','AND','OR','XOR','Implication',2,'XOR is 1 exactly when the membership bits differ.')
add('Sets','(101101 OR 110001) XOR 001101 equals:','101100','110000','001101','111101',1,'OR gives 111101; XOR 001101 gives 110000.')
add('Sets','A function R -> Z must output:','Any real','Exactly one integer for every real input','Two integers per input','Only positive integers',1,'A function must be defined for every domain element and land in its codomain.')
add('Sets','Which rule defines R -> Z?','1/floor(x)','ceil(x+pi)','sqrt(x^2+1)','1/x',1,'Ceiling always returns an integer and is defined for every real x.')
add('Sets','If domain has 5 elements and codomain has 4, injective functions:','0','4!','5!','4^5',0,'Injection is impossible when the domain is larger than the codomain.')
add('Sets','Number of all functions from m elements to n elements:','m^n','n^m','m!','n!',1,'Each of m inputs independently chooses one of n outputs.')
add('Sets','A one-to-one function count from m to n (m<=n):','n^m','n!/(n-m)!','m!','n-m',1,'Choose distinct images in order: P(n,m).')
add('Sets','floor(floor(x)) equals:','ceil(x)','floor(x)','x','0',1,'The floor of an integer is itself.')
add('Sets','ceil(floor(x)) equals:','floor(x)','ceil(x)','x','1',0,'floor(x) is already an integer.')
add('Sets','Is floor(xy)=floor(x)floor(y) always true?','Yes','No','Only x=y','Only integers',1,'A counterexample is x=y=1.5: floor(2.25)=2 but 1*1=1.')
add('Sets','A set with no elements has cardinality:','-1','0','1','Undefined',1,'The empty set contains zero elements.')
add('Sets','{empty} compared with empty set:','They are equal','{empty} has one element','Both have zero elements','Neither is a set',1,'The first set contains the empty set as one element.')

# NUMBER THEORY / ALGORITHMS
add('Number','gcd(899,941) is:','1','13','17','29',0,'Euclidean algorithm gives gcd 1, so the original multiple-choice answer is None.')
add('Number','gcd(2^3*3^2*5*7, 2^4*5^2*11^3):','40','120','360','2310',0,'Use common primes with minimum exponents: 2^3*5=40.')
add('Number','1025=p^2*q with primes p,q. q-p is:','11','36','46','66',1,'1025=5^2*41, so q-p=41-5=36.')
add('Number','Convert hexadecimal 2BE0 to binary:','0010101111100000','0011111111000000','0010101011100000','0010101111110000',0,'Map each hex digit to four bits: 2=0010,B=1011,E=1110,0=0000.')
add('Number','For floor division, -124 div 15 is:','-8','-9','8','9',1,'-124=15*(-9)+11 with nonnegative remainder.')
add('Number','For floor modulo, -107 mod 15 is:','-2','2','13','-13',2,'-107=15*(-8)+13.')
add('Number','Positive integers <=200 divisible by 5 or 7:','63','64','65','66',0,'40+28-floor(200/35)=40+28-5=63.')
add('Number','A linear congruential sequence x0=1, x(n+1)=(3xn+4) mod 7. x3:','2','4','7','16',0,'x1=0,x2=4,x3=2.')
add('Number','x0=3, xn=(5x(n-1)+4) mod 7. x4:','0','2','4','6',0,'x1=5,x2=1,x3=2,x4=0.')
add('Algorithm','Insertion sort on 7,2,4,3,1,6,5 after i=4:','2,3,4,7,1,6,5','2,4,7,3,1,6,5','1,2,3,4,7,6,5','2,4,7,1,3,6,5',0,'After inserting the fourth item 3, the first four are sorted.')
add('Algorithm','Binary search worst-case comparisons are:','O(1)','O(log n)','O(n)','O(n^2)',1,'The search interval is halved each comparison.')
add('Algorithm','Merge sort complexity is:','O(log n)','O(n)','O(n log n)','O(n^2)',2,'There are log n levels and O(n) work per level.')
add('Algorithm','An algorithm must:','Always use recursion','Terminate after finitely many steps','Use integers only','Have O(1) time',1,'Finiteness is a defining property of an algorithm.')
add('Algorithm','A loop while n>0 with n:=n-1 is:','Nonterminating','Terminating for positive n','Only recursive','Undefined',1,'n strictly decreases to zero.')
add('Algorithm','If f=O(log n), g=O(1), h=O(n), best bound for f^3+(g+2)h:','O(log n)','O(n)','O(n log n)','O(n^2)',1,'(log n)^3 grows slower than n, while constant times n is O(n).')
add('Algorithm','2^(n^2) operations at 10^-12 sec each; largest n within one second:','6','7','39','40',0,'Need 2^(n^2)<=10^12. Since log2(10^12) is about 39.86, n^2<=39.86 and n=6.')
add('Algorithm','Divide-and-conquer recurrence has form:','f(n)=f(n-1)+n','f(n)=f(n-1)+f(n-2)','f(n)=a f(n/b)+g(n)','f(n)=2f(n-1)+1',2,'The problem is split into a subproblems of size n/b plus combine cost g(n).')
add('Algorithm','Prefix of ((x+y)^3)-2 is:','- ^ + x y 3 2','+ - ^ x y 2 3','- + x y ^ 3 2','^ - + x y 3 2',0,'Prefix places each operator before its two operands.')
add('Algorithm','Postfix of (x-y)^2+x(y+5):','x y - 2 ^ x y 5 + * +','+ ^ - x y 2 * x + y 5','x y - 2 + x y 5 * +','x y 2 - ^ x 5 y + * +',0,'Convert each subexpression then place the final + last.')
add('Algorithm','A binary search tree search follows:','Random child','Left for smaller, right for larger','Always left','Breadth-first only',1,'BST ordering determines the next branch.')

# COUNTING / RECURRENCE
add('Counting','First n positive even integers sum to:','n(n+1)','n^2','2n^2','n(n-1)',0,'2+4+...+2n=2*n(n+1)/2.')
add('Counting','First n positive odd integers sum to:','n(n+1)','n^2','2n','2^n',1,'1+3+...+(2n-1)=n^2.')
add('Counting','Distinct Hamilton circuits in K4 (rotation and reversal same):','3','4','6','8',0,'(n-1)!/2=3! /2=3.')
add('Counting','Spanning trees of K2,2:','1','2','3','4',3,'K2,2 is a 4-cycle; deleting any one edge gives a spanning tree.')
add('Counting','Spanning trees of Kn:','n!','n^(n-2)','2^n','n(n-1)/2',1,'Cayley formula gives n^(n-2).')
add('Counting','Spanning trees of Km,n:','m*n','m^(n-1)n^(m-1)','(m+n)!','2^(mn)',1,'This is the complete bipartite spanning-tree formula.')
add('Counting','How many functions 5 -> 4 are one-to-one?','0','20','24','120',0,'No injection exists from a larger finite set to a smaller one.')
add('Counting','How many ways choose ordered first,second,third from 12 teams?','220','1320','1728','36',1,'12*11*10=1320.')
add('Counting','A 6-character password from 62 symbols has:','62*6','62^6','6^62','62!',1,'Each of six positions has 62 independent choices.')
add('Counting','How many positive divisors has 120=2^3*3*5?','8','12','16','24',2,'(3+1)(1+1)(1+1)=16.')
add('Counting','Count integers <=N divisible by a or b uses:','N/a+N/b','floor(N/a)+floor(N/b)-floor(N/lcm)','floor(N/gcd)','N-ab',1,'Inclusion-exclusion subtracts numbers counted twice.')
add('Recurrence','f(1)=4, f(n)=n f(n-1). f(5):','120','240','360','480',3,'4*2*3*4*5=480.')
add('Recurrence','T(n)=3 for n<3; even n returns n; odd n returns 3T(n-1)-2. T(9):','9','22','25','27',1,'T8=8, so T9=3*8-2=22.')
add('Recurrence','f(0)=2, f(n+1)=f(n)^2+2f(n)-3. f(3):','32','93','1085','15',2,'f1=5,f2=32,f3=1085.')
add('Recurrence','Sequence a_n=2^n-n!, n=0..4:','0,1,2,2,-8','1,1,2,2,-8','0,1,2,3,-8','0,1,2,2,-18',0,'Use 0!=1: 1-1=0, then 2-1,4-2,8-6,16-24.')
add('Recurrence','Recursive set starts (0,0); add (2,3) or (3,2). Which is reachable?','(7,8)','(6,7)','(8,9)','(5,10)',0,'(7,8)=(2,3)+(2,3)+(3,2).')
add('Recurrence','A recursive definition needs:','Only a rule','Basis and recursive steps','A graph','A probability',1,'The basis starts the construction and the recursive step extends it.')
add('Recurrence','Fibonacci recursive evaluation is usually:','Faster than iteration','More computations than iteration','Always O(1)','Not an algorithm',1,'Naive recursion repeats subproblems.')

# GRAPHS / TREES
add('Graph','Kn has how many edges?','n','n(n-1)/2','2n','n^2',1,'Every unordered pair of vertices forms one edge.')
add('Graph','Km,n has how many edges?','m+n','mn','m(n-1)','m^n',1,'Each vertex in one part connects to all vertices in the other part.')
add('Graph','Cn has vertices and edges:','n and n','n+1 and 2n','n and n-1','2n and n',0,'A cycle has one edge per vertex.')
add('Graph','Using course convention, Wn has:','n vertices,n edges','n+1 vertices,2n edges','2n vertices,n edges','n vertices,2n edges',1,'Wn is Cn plus one hub connected to all rim vertices.')
add('Graph','Qn has vertices:','n^2','2n','2^n','n!',2,'Each vertex is an n-bit string.')
add('Graph','Qn has edges:','n2^(n-1)','2^n','n(n-1)/2','n^2',0,'Sum degrees n*2^n and divide by 2.')
add('Graph','Kn has an Euler circuit when:','n is even','n is odd','all n','no n',1,'Each vertex degree is n-1, which is even exactly when n is odd.')
add('Graph','A connected graph has Euler path but no circuit when odd-degree vertices:','0','1','2','4',2,'Exactly two odd vertices are the endpoints.')
add('Graph','A connected graph has Euler circuit when:','Every degree even','Exactly two odd','All degrees distinct','It is complete',0,'Euler circuit criterion: all vertices have even degree.')
add('Graph','A loop contributes to degree:','0','1','2','Depends on weight',2,'A loop touches its vertex twice.')
add('Graph','Adjacency matrix A: number of walks length k from i to j:','A[i,j]+k','Entry (i,j) of A^k','det(A)','trace(A)',1,'Matrix multiplication counts intermediate choices.')
add('Graph','Adjacency matrix of a graph with n vertices has rows:','edges','n','2n','n-1',1,'There is one row and one column for each vertex.')
add('Graph','Incidence matrix columns correspond to:','Vertices','Edges','Paths','Components',1,'Rows represent vertices and columns represent edges.')
add('Graph','A simple graph permits:','Loops only','Parallel edges only','Neither loops nor parallel edges','Both',2,'Simple graphs have no loops and no multiple edges.')
add('Graph','A multigraph differs from a simple graph by allowing:','No vertices','Multiple edges','Only loops','Directions only',1,'Parallel edges between a pair of vertices may occur.')
add('Graph','A pseudograph may contain:','Loops','No edges','Only directed edges','No vertices',0,'A pseudograph permits loops and may also permit multiple edges.')
add('Graph','Degree sequence 3,3,3,3,2 on 5 vertices is:','Impossible by odd sum','Graphical','Has a loop','Directed only',1,'Sum is 14 and Havel-Hakimi succeeds.')
add('Graph','Degree sequence 1,2,3,4,4 on 5 vertices is:','Graphical','Not graphical','Always a tree','Eulerian',1,'After connecting a degree-4 vertex, the reduced sequence fails Havel-Hakimi.')
add('Graph','Dijkstra requires edge weights to be:','All negative','Nonnegative','All equal','Prime',1,'Standard Dijkstra is correct for nonnegative weights.')
add('Graph','Prim algorithm builds:','Shortest path tree','Minimum spanning tree','Hamilton circuit','Topological order',1,'Prim repeatedly adds the lightest edge crossing the current cut.')
add('Graph','A spanning tree of n vertices has edges:','n','n-1','n+1','2n',1,'Every tree on n vertices has n-1 edges.')
add('Tree','Full binary tree with 61 vertices has leaves:','30','31','60','61',1,'For full binary tree, n=2i+1, so i=30 and leaves=i+1=31.')
add('Tree','Full 3-ary tree with 101 leaves has vertices:','151','200','304','101',0,'i=(101-1)/(3-1)=50; vertices=3*50+1=151.')
add('Tree','Full m-ary tree with i internal vertices has total vertices:','mi+1','(m-1)i+1','m+i','mi-1',0,'Each internal vertex contributes m child edges; n=mi+1.')
add('Tree','Full m-ary tree with i internal vertices has leaves:','mi+1','(m-1)i+1','i+1','m^i',1,'Leaves equal total minus internal: (m-1)i+1.')
add('Tree','Binary search tree key smaller than current node goes:','Right','Left','Root','Randomly',1,'BST invariant places smaller keys in the left subtree.')
add('Tree','Prefix code validity requires:','All codes same length','No codeword is a prefix of another','Codes use decimal','Exactly two symbols',1,'This property allows unambiguous instantaneous decoding.')
add('Tree','Huffman coding repeatedly combines:','Two largest frequencies','Two smallest frequencies','First and last','Equal frequencies only',1,'Greedy Huffman construction merges the two least frequent nodes.')
add('Tree','Minimum height h of a binary tree with n vertices satisfies:','n<=2^(h+1)-1','n<=h^2','h=n-1 always','n=2h',0,'A binary tree of height h has at most 2^(h+1)-1 vertices.')
add('Tree','A tree is connected and has:','One cycle','No cycles','Two components','All even degrees',1,'Connected acyclic graphs are exactly trees.')

# Corrections for intentionally tricky source items are handled below.
# Remove exact duplicates by normalized question text.
seen=set(); unique=[]
for item in Q:
    key=' '.join(item[1].lower().split())
    if key not in seen:
        seen.add(key); unique.append(item)
Q=unique

def esc(s):
    return s.replace('\\','\\\\').replace('"','\\"')

out=['#include "quiz.h"','','const MadQuizQuestion MAD_QUIZ[] = {']
for cat,q,choices,ans,exp in Q:
    out.append('    {"%s", "%s", {"%s", "%s", "%s", "%s"}, %d, "%s"},' % (
        esc(cat),esc(q),*(esc(x) for x in choices),ans,esc(exp)))
out += ['};','','const int MAD_QUIZ_COUNT = (int)(sizeof(MAD_QUIZ) / sizeof(MAD_QUIZ[0]));','']
Path(__file__).resolve().parents[1].joinpath('src/quiz_data.c').write_text('\n'.join(out),encoding='utf-8')
Path(__file__).resolve().parents[1].joinpath('data/question_bank.tsv').write_text(
    'category\tquestion\tA\tB\tC\tD\tanswer\texplanation\n'+'\n'.join(
        '\t'.join([cat,q,*choices,'ABCD'[ans],exp]) for cat,q,choices,ans,exp in Q
    ),encoding='utf-8')
print(f'Generated {len(Q)} unique questions')
