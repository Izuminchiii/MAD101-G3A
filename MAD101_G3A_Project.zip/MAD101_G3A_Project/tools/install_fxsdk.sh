#!/usr/bin/env bash
set -euo pipefail

# Ubuntu / Debian / WSL helper. The fxSDK ecosystem changes over time;
# check the current upstream instructions if a package name changes.

sudo apt-get update
sudo apt-get install -y \
  build-essential cmake git curl pkg-config \
  python3 python3-pip python3-pil \
  libpng-dev libusb-1.0-0-dev

curl -L \
  https://gitea.planet-casio.com/Lephenixnoir/GiteaPC/raw/branch/master/install.sh \
  -o /tmp/giteapc-install.sh

yes | bash /tmp/giteapc-install.sh

export PATH="$HOME/.local/bin:$PATH"

# Install the toolchain and runtime in dependency order.
giteapc install Lephenixnoir/fxsdk
giteapc install Lephenixnoir/sh-elf-gcc
giteapc install Lephenixnoir/OpenLibm
giteapc install Vhex-Kernel-Core/fxlibc
giteapc install Lephenixnoir/gint

echo "fxSDK installation finished. Re-open the shell if fxsdk is not on PATH."
