#include "core.h"

#include <limits.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

static int mul_overflow_i64(int64_t a, int64_t b, int64_t *out)
{
#if defined(__GNUC__)
    return __builtin_mul_overflow(a, b, out);
#else
    if(a == 0 || b == 0) { *out = 0; return 0; }
    if(a == -1 && b == INT64_MIN) return 1;
    if(b == -1 && a == INT64_MIN) return 1;
    int64_t r = a * b;
    if(r / b != a) return 1;
    *out = r;
    return 0;
#endif
}

static int add_overflow_i64(int64_t a, int64_t b, int64_t *out)
{
#if defined(__GNUC__)
    return __builtin_add_overflow(a, b, out);
#else
    if((b > 0 && a > INT64_MAX - b) || (b < 0 && a < INT64_MIN - b)) return 1;
    *out = a + b;
    return 0;
#endif
}

static int64_t pow_i64_checked(int64_t base, int exp, int *overflow)
{
    int64_t result = 1;
    int64_t cur = base;
    *overflow = 0;
    while(exp > 0) {
        if(exp & 1) {
            if(mul_overflow_i64(result, cur, &result)) { *overflow = 1; return 0; }
        }
        exp >>= 1;
        if(exp > 0 && mul_overflow_i64(cur, cur, &cur)) { *overflow = 1; return 0; }
    }
    return result;
}

int64_t mad_abs64(int64_t x)
{
    return x < 0 ? -x : x;
}

int64_t mad_gcd(int64_t a, int64_t b)
{
    a = mad_abs64(a);
    b = mad_abs64(b);
    while(b != 0) {
        int64_t r = a % b;
        a = b;
        b = r;
    }
    return a;
}

int64_t mad_lcm(int64_t a, int64_t b)
{
    if(a == 0 || b == 0) return 0;
    int64_t g = mad_gcd(a, b);
    int64_t r;
    if(mul_overflow_i64(a / g, b, &r)) return 0;
    return mad_abs64(r);
}

void mad_extended_gcd(int64_t a, int64_t b, int64_t *g, int64_t *x, int64_t *y)
{
    int64_t old_r = a, r = b;
    int64_t old_s = 1, s = 0;
    int64_t old_t = 0, t = 1;
    while(r != 0) {
        int64_t q = old_r / r;
        int64_t nr = old_r - q * r;
        int64_t ns = old_s - q * s;
        int64_t nt = old_t - q * t;
        old_r = r; r = nr;
        old_s = s; s = ns;
        old_t = t; t = nt;
    }
    if(old_r < 0) { old_r = -old_r; old_s = -old_s; old_t = -old_t; }
    if(g) *g = old_r;
    if(x) *x = old_s;
    if(y) *y = old_t;
}

void mad_floor_divmod(int64_t a, int64_t b, int64_t *q, int64_t *r)
{
    if(b == 0) { if(q) *q = 0; if(r) *r = 0; return; }
    int64_t qq = a / b;
    int64_t rr = a % b;
    if(rr != 0 && ((rr > 0) != (b > 0))) {
        qq -= 1;
        rr += b;
    }
    if(q) *q = qq;
    if(r) *r = rr;
}

int mad_is_prime(int64_t n)
{
    if(n < 2) return 0;
    if(n % 2 == 0) return n == 2;
    if(n % 3 == 0) return n == 3;
    for(int64_t i = 5; i <= n / i; i += 6) {
        if(n % i == 0 || n % (i + 2) == 0) return 0;
    }
    return 1;
}

int mad_prime_factorization(int64_t n, int64_t *primes, int *powers, int max_terms)
{
    n = mad_abs64(n);
    if(n < 2 || max_terms <= 0) return 0;
    int count = 0;
    int64_t p = 2;
    while(p <= n / p) {
        if(n % p == 0) {
            int e = 0;
            while(n % p == 0) { n /= p; e++; }
            if(count < max_terms) {
                primes[count] = p;
                powers[count] = e;
                count++;
            } else return -1;
        }
        p = (p == 2) ? 3 : p + 2;
    }
    if(n > 1) {
        if(count >= max_terms) return -1;
        primes[count] = n;
        powers[count] = 1;
        count++;
    }
    return count;
}

int64_t mad_divisor_count(int64_t n)
{
    n = mad_abs64(n);
    if(n == 0) return 0;
    if(n == 1) return 1;
    int64_t primes[32]; int powers[32];
    int count = mad_prime_factorization(n, primes, powers, 32);
    if(count < 0) return 0;
    int64_t result = 1;
    for(int i = 0; i < count; i++) {
        int64_t next;
        if(mul_overflow_i64(result, powers[i] + 1, &next)) return 0;
        result = next;
    }
    return result;
}

int64_t mad_mod_pow(int64_t base, int64_t exp, int64_t mod)
{
    if(mod <= 0 || exp < 0) return 0;
    base %= mod;
    if(base < 0) base += mod;
    int64_t result = 1 % mod;
    while(exp > 0) {
        if(exp & 1) result = (result * base) % mod;
        base = (base * base) % mod;
        exp >>= 1;
    }
    return result;
}

int mad_to_base(int64_t value, int base, char *out, size_t out_size)
{
    static const char digits[] = "0123456789ABCDEF";
    if(!out || out_size < 2 || base < 2 || base > 16) return 0;
    char tmp[70]; size_t pos = 0;
    uint64_t x;
    int negative = value < 0;
    if(negative) x = (uint64_t)(-(value + 1)) + 1;
    else x = (uint64_t)value;
    do {
        tmp[pos++] = digits[x % (uint64_t)base];
        x /= (uint64_t)base;
    } while(x && pos < sizeof(tmp));
    if(negative) tmp[pos++] = '-';
    if(pos + 1 > out_size) return 0;
    for(size_t i = 0; i < pos; i++) out[i] = tmp[pos - 1 - i];
    out[pos] = '\0';
    return 1;
}

MadIntResult mad_from_base(const char *text, int base)
{
    MadIntResult res = {0, 0};
    if(!text || base < 2 || base > 16) return res;
    while(isspace((unsigned char)*text)) text++;
    int negative = 0;
    if(*text == '-') { negative = 1; text++; }
    if(!*text) return res;
    int64_t value = 0;
    for(; *text; text++) {
        if(isspace((unsigned char)*text)) break;
        int d;
        char c = (char)toupper((unsigned char)*text);
        if(c >= '0' && c <= '9') d = c - '0';
        else if(c >= 'A' && c <= 'F') d = 10 + c - 'A';
        else return res;
        if(d >= base) return res;
        int64_t next;
        if(mul_overflow_i64(value, base, &next) || add_overflow_i64(next, d, &next)) return res;
        value = next;
    }
    res.valid = 1;
    res.value = negative ? -value : value;
    return res;
}

int64_t mad_factorial(int n, int *overflow)
{
    if(overflow) *overflow = 0;
    if(n < 0) { if(overflow) *overflow = 1; return 0; }
    int64_t r = 1;
    for(int i = 2; i <= n; i++) {
        if(mul_overflow_i64(r, i, &r)) { if(overflow) *overflow = 1; return 0; }
    }
    return r;
}

int64_t mad_permutation(int n, int r, int *overflow)
{
    if(overflow) *overflow = 0;
    if(n < 0 || r < 0 || r > n) { if(overflow) *overflow = 1; return 0; }
    int64_t result = 1;
    for(int i = 0; i < r; i++) {
        if(mul_overflow_i64(result, n - i, &result)) { if(overflow) *overflow = 1; return 0; }
    }
    return result;
}

int64_t mad_combination(int n, int r, int *overflow)
{
    if(overflow) *overflow = 0;
    if(n < 0 || r < 0 || r > n) { if(overflow) *overflow = 1; return 0; }
    if(r > n - r) r = n - r;
    int64_t result = 1;
    for(int i = 1; i <= r; i++) {
        int64_t num = n - r + i;
        int64_t g1 = mad_gcd(num, i);
        num /= g1;
        int64_t den = i / g1;
        int64_t g2 = mad_gcd(result, den);
        result /= g2;
        den /= g2;
        if(den != 1) return 0;
        if(mul_overflow_i64(result, num, &result)) { if(overflow) *overflow = 1; return 0; }
    }
    return result;
}

int64_t mad_count_functions(int domain_size, int codomain_size, int *overflow)
{
    if(domain_size < 0 || codomain_size < 0) { if(overflow) *overflow = 1; return 0; }
    return pow_i64_checked(codomain_size, domain_size, overflow);
}

int64_t mad_count_injections(int domain_size, int codomain_size, int *overflow)
{
    if(domain_size > codomain_size) { if(overflow) *overflow = 0; return 0; }
    return mad_permutation(codomain_size, domain_size, overflow);
}

int64_t mad_count_surjections(int domain_size, int codomain_size, int *overflow)
{
    if(overflow) *overflow = 0;
    if(domain_size < 0 || codomain_size < 0) { if(overflow) *overflow = 1; return 0; }
    if(codomain_size == 0) return domain_size == 0 ? 1 : 0;
    if(domain_size < codomain_size) return 0;
    int64_t total = 0;
    for(int k = 0; k <= codomain_size; k++) {
        int ov1 = 0, ov2 = 0;
        int64_t comb = mad_combination(codomain_size, k, &ov1);
        int64_t powv = pow_i64_checked(codomain_size - k, domain_size, &ov2);
        int64_t term;
        if(ov1 || ov2 || mul_overflow_i64(comb, powv, &term)) { if(overflow) *overflow = 1; return 0; }
        int64_t next;
        if(k % 2 == 0) {
            if(add_overflow_i64(total, term, &next)) { if(overflow) *overflow = 1; return 0; }
        } else {
            if(add_overflow_i64(total, -term, &next)) { if(overflow) *overflow = 1; return 0; }
        }
        total = next;
    }
    return total;
}

int64_t mad_inclusion_two(int64_t limit, int64_t a, int64_t b)
{
    a = mad_abs64(a); b = mad_abs64(b);
    if(limit <= 0 || a == 0 || b == 0) return 0;
    int64_t l = mad_lcm(a, b);
    return limit / a + limit / b - (l ? limit / l : 0);
}

int64_t mad_sum_even(int64_t n)
{
    if(n < 0) return 0;
    return n * (n + 1);
}

int64_t mad_sum_odd(int64_t n)
{
    if(n < 0) return 0;
    return n * n;
}

double mad_compound_interest(double principal, double rate_percent, int years, int compounds_per_year)
{
    if(compounds_per_year <= 0 || years < 0) return 0.0;
    double r = rate_percent / 100.0;
    return principal * pow(1.0 + r / compounds_per_year, compounds_per_year * years);
}

int64_t mad_lcg_term(int64_t x0, int64_t a, int64_t c, int64_t m, int n)
{
    if(m <= 0 || n < 0) return 0;
    int64_t x = x0 % m;
    if(x < 0) x += m;
    for(int i = 0; i < n; i++) {
        x = (a * x + c) % m;
        if(x < 0) x += m;
    }
    return x;
}

int64_t mad_linear_recurrence2(int64_t f0, int64_t f1, int64_t a, int64_t b, int64_t c, int n, int *overflow)
{
    if(overflow) *overflow = 0;
    if(n < 0) { if(overflow) *overflow = 1; return 0; }
    if(n == 0) return f0;
    if(n == 1) return f1;
    int64_t p = f0, q = f1;
    for(int i = 2; i <= n; i++) {
        int64_t ap, bq, sum, next;
        if(mul_overflow_i64(a, q, &ap) || mul_overflow_i64(b, p, &bq) ||
           add_overflow_i64(ap, bq, &sum) || add_overflow_i64(sum, c, &next)) {
            if(overflow) *overflow = 1;
            return 0;
        }
        p = q; q = next;
    }
    return q;
}

int64_t mad_recurrence_square(int64_t f0, int64_t a, int64_t b, int n, int *overflow)
{
    if(overflow) *overflow = 0;
    if(n < 0) { if(overflow) *overflow = 1; return 0; }
    int64_t f = f0;
    for(int i = 0; i < n; i++) {
        int64_t sq, af, sum, next;
        if(mul_overflow_i64(f, f, &sq) || mul_overflow_i64(a, f, &af) ||
           add_overflow_i64(sq, af, &sum) || add_overflow_i64(sum, b, &next)) {
            if(overflow) *overflow = 1;
            return 0;
        }
        f = next;
    }
    return f;
}

int mad_full_mary_from_internal(int m, int internal, int *vertices, int *leaves)
{
    if(m < 2 || internal < 0) return 0;
    if(vertices) *vertices = m * internal + 1;
    if(leaves) *leaves = (m - 1) * internal + 1;
    return 1;
}

int mad_full_mary_from_leaves(int m, int leaves, int *internal, int *vertices)
{
    if(m < 2 || leaves < 1 || (leaves - 1) % (m - 1) != 0) return 0;
    int i = (leaves - 1) / (m - 1);
    if(internal) *internal = i;
    if(vertices) *vertices = m * i + 1;
    return 1;
}

int mad_full_mary_from_vertices(int m, int vertices, int *internal, int *leaves)
{
    if(m < 2 || vertices < 1 || (vertices - 1) % m != 0) return 0;
    int i = (vertices - 1) / m;
    if(internal) *internal = i;
    if(leaves) *leaves = (m - 1) * i + 1;
    return 1;
}

int64_t mad_complete_graph_edges(int n)
{
    if(n < 0) return 0;
    return (int64_t)n * (n - 1) / 2;
}

int64_t mad_complete_bipartite_edges(int m, int n)
{
    if(m < 0 || n < 0) return 0;
    return (int64_t)m * n;
}

int64_t mad_hypercube_vertices(int n)
{
    if(n < 0 || n > 62) return 0;
    return (int64_t)1 << n;
}

int64_t mad_hypercube_edges(int n)
{
    if(n <= 0 || n > 61) return n == 0 ? 0 : 0;
    return (int64_t)n * ((int64_t)1 << (n - 1));
}

int64_t mad_hamilton_complete(int n, int *overflow)
{
    if(n < 3) { if(overflow) *overflow = 0; return 0; }
    int64_t f = mad_factorial(n - 1, overflow);
    return (overflow && *overflow) ? 0 : f / 2;
}

int64_t mad_spanning_complete(int n, int *overflow)
{
    if(n <= 0) { if(overflow) *overflow = 1; return 0; }
    if(n == 1) { if(overflow) *overflow = 0; return 1; }
    return pow_i64_checked(n, n - 2, overflow);
}

int64_t mad_spanning_complete_bipartite(int m, int n, int *overflow)
{
    if(overflow) *overflow = 0;
    if(m <= 0 || n <= 0) { if(overflow) *overflow = 1; return 0; }
    int ov1 = 0, ov2 = 0;
    int64_t a = pow_i64_checked(m, n - 1, &ov1);
    int64_t b = pow_i64_checked(n, m - 1, &ov2);
    int64_t result;
    if(ov1 || ov2 || mul_overflow_i64(a, b, &result)) { if(overflow) *overflow = 1; return 0; }
    return result;
}

int mad_euler_type(const int *degrees, int n)
{
    if(!degrees || n <= 0) return 0;
    int odd = 0;
    for(int i = 0; i < n; i++) {
        if(degrees[i] < 0) return 0;
        if(degrees[i] & 1) odd++;
    }
    if(odd == 0) return 2;
    if(odd == 2) return 1;
    return 0;
}

static int int_cmp_desc(const void *a, const void *b)
{
    int x = *(const int *)a, y = *(const int *)b;
    return (y > x) - (y < x);
}

int mad_is_graphical(const int *degrees, int n)
{
    if(!degrees || n < 0 || n > 64) return 0;
    int d[64];
    int64_t sum = 0;
    for(int i = 0; i < n; i++) {
        if(degrees[i] < 0 || degrees[i] >= n) return 0;
        d[i] = degrees[i]; sum += degrees[i];
    }
    if(sum & 1) return 0;
    int len = n;
    while(len > 0) {
        qsort(d, len, sizeof(int), int_cmp_desc);
        while(len > 0 && d[len - 1] == 0) len--;
        if(len == 0) return 1;
        int k = d[0];
        if(k < 0 || k >= len) return 0;
        for(int i = 1; i < len; i++) d[i - 1] = d[i];
        len--;
        for(int i = 0; i < k; i++) {
            if(i >= len || d[i] <= 0) return 0;
            d[i]--;
        }
    }
    return 1;
}

void mad_graph_init(MadGraph *g, int n)
{
    if(!g) return;
    if(n < 0) n = 0;
    if(n > MAD_MAX_VERTICES) n = MAD_MAX_VERTICES;
    g->n = n;
    for(int i = 0; i < MAD_MAX_VERTICES; i++) {
        for(int j = 0; j < MAD_MAX_VERTICES; j++) g->w[i][j] = (i == j ? 0 : MAD_INF);
    }
}

int mad_graph_add_edge(MadGraph *g, int u, int v, int weight, int undirected)
{
    if(!g || u < 0 || v < 0 || u >= g->n || v >= g->n || weight < 0) return 0;
    if(weight < g->w[u][v]) g->w[u][v] = weight;
    if(undirected && weight < g->w[v][u]) g->w[v][u] = weight;
    return 1;
}

int mad_dijkstra(const MadGraph *g, int source, int *dist, int *parent)
{
    if(!g || source < 0 || source >= g->n || !dist || !parent) return 0;
    int used[MAD_MAX_VERTICES] = {0};
    for(int i = 0; i < g->n; i++) { dist[i] = MAD_INF; parent[i] = -1; }
    dist[source] = 0;
    for(int it = 0; it < g->n; it++) {
        int u = -1;
        for(int i = 0; i < g->n; i++) if(!used[i] && (u < 0 || dist[i] < dist[u])) u = i;
        if(u < 0 || dist[u] == MAD_INF) break;
        used[u] = 1;
        for(int v = 0; v < g->n; v++) {
            if(g->w[u][v] < MAD_INF && !used[v] && dist[u] <= MAD_INF - g->w[u][v]) {
                int nd = dist[u] + g->w[u][v];
                if(nd < dist[v]) { dist[v] = nd; parent[v] = u; }
            }
        }
    }
    return 1;
}

int mad_prim(const MadGraph *g, int start, int *parent, int *total_weight)
{
    if(!g || start < 0 || start >= g->n || !parent || !total_weight) return 0;
    int key[MAD_MAX_VERTICES], used[MAD_MAX_VERTICES] = {0};
    for(int i = 0; i < g->n; i++) { key[i] = MAD_INF; parent[i] = -1; }
    key[start] = 0;
    int total = 0;
    for(int it = 0; it < g->n; it++) {
        int u = -1;
        for(int i = 0; i < g->n; i++) if(!used[i] && (u < 0 || key[i] < key[u])) u = i;
        if(u < 0 || key[u] == MAD_INF) return 0;
        used[u] = 1;
        total += key[u];
        for(int v = 0; v < g->n; v++) {
            if(!used[v] && g->w[u][v] < key[v]) { key[v] = g->w[u][v]; parent[v] = u; }
        }
    }
    *total_weight = total;
    return 1;
}

int mad_walk_count(const int *matrix, int n, int length, int from, int to, int64_t *answer)
{
    if(!matrix || !answer || n <= 0 || n > 6 || length < 0 || from < 0 || to < 0 || from >= n || to >= n) return 0;
    int64_t result[36] = {0}, base[36] = {0}, temp[36] = {0};
    for(int i = 0; i < n; i++) result[i*n+i] = 1;
    for(int i = 0; i < n*n; i++) base[i] = matrix[i];
    int e = length;
    while(e > 0) {
        if(e & 1) {
            memset(temp, 0, sizeof(temp));
            for(int i = 0; i < n; i++) for(int j = 0; j < n; j++) for(int k = 0; k < n; k++) {
                int64_t prod, sum;
                if(mul_overflow_i64(result[i*n+k], base[k*n+j], &prod) || add_overflow_i64(temp[i*n+j], prod, &sum)) return 0;
                temp[i*n+j] = sum;
            }
            memcpy(result, temp, sizeof(result));
        }
        e >>= 1;
        if(e > 0) {
            memset(temp, 0, sizeof(temp));
            for(int i = 0; i < n; i++) for(int j = 0; j < n; j++) for(int k = 0; k < n; k++) {
                int64_t prod, sum;
                if(mul_overflow_i64(base[i*n+k], base[k*n+j], &prod) || add_overflow_i64(temp[i*n+j], prod, &sum)) return 0;
                temp[i*n+j] = sum;
            }
            memcpy(base, temp, sizeof(base));
        }
    }
    *answer = result[from*n+to];
    return 1;
}

int mad_binary_search_comparisons(const int *sorted, int n, int target)
{
    if(!sorted || n < 0) return 0;
    int lo = 0, hi = n - 1, comparisons = 0;
    while(lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        comparisons++;
        if(sorted[mid] == target) return comparisons;
        if(sorted[mid] < target) lo = mid + 1;
        else hi = mid - 1;
    }
    return comparisons;
}

void mad_insertion_sort_prefix(int *a, int n, int outer_iterations)
{
    if(!a || n <= 0) return;
    if(outer_iterations < 0) outer_iterations = 0;
    if(outer_iterations > n - 1) outer_iterations = n - 1;
    for(int i = 1; i <= outer_iterations; i++) {
        int x = a[i], j = i - 1;
        while(j >= 0 && a[j] > x) { a[j + 1] = a[j]; j--; }
        a[j + 1] = x;
    }
}

static int apply_op(char op, int64_t a, int64_t b, int64_t *out)
{
    switch(op) {
        case '+': return !add_overflow_i64(a, b, out);
        case '-': return !add_overflow_i64(a, -b, out);
        case '*': return !mul_overflow_i64(a, b, out);
        case '/': if(b == 0) return 0; *out = a / b; return 1;
        case '%': if(b == 0) return 0; *out = a % b; return 1;
        case '^': {
            if(b < 0 || b > 62) return 0;
            int ov = 0; *out = pow_i64_checked(a, (int)b, &ov); return !ov;
        }
        default: return 0;
    }
}

static int tokenize(const char *expr, char tokens[][24], int max_tokens)
{
    int count = 0;
    while(expr && *expr) {
        while(isspace((unsigned char)*expr)) expr++;
        if(!*expr) break;
        if(count >= max_tokens) return -1;
        int len = 0;
        while(*expr && !isspace((unsigned char)*expr) && len < 23) tokens[count][len++] = *expr++;
        tokens[count][len] = '\0';
        while(*expr && !isspace((unsigned char)*expr)) expr++;
        count++;
    }
    return count;
}

int mad_eval_postfix(const char *expr, int64_t *result)
{
    char tok[64][24];
    int n = tokenize(expr, tok, 64);
    if(n <= 0 || !result) return 0;
    int64_t stack[64]; int top = 0;
    for(int i = 0; i < n; i++) {
        if(strlen(tok[i]) == 1 && strchr("+-*/%^", tok[i][0])) {
            if(top < 2) return 0;
            int64_t b = stack[--top], a = stack[--top], r;
            if(!apply_op(tok[i][0], a, b, &r)) return 0;
            stack[top++] = r;
        } else {
            char *end = NULL;
            long long v = strtoll(tok[i], &end, 10);
            if(!end || *end) return 0;
            stack[top++] = (int64_t)v;
        }
    }
    if(top != 1) return 0;
    *result = stack[0];
    return 1;
}

static int eval_prefix_rec(char tokens[][24], int n, int *index, int64_t *out)
{
    if(*index >= n) return 0;
    char *t = tokens[(*index)++];
    if(strlen(t) == 1 && strchr("+-*/%^", t[0])) {
        int64_t a, b;
        if(!eval_prefix_rec(tokens, n, index, &a) || !eval_prefix_rec(tokens, n, index, &b)) return 0;
        return apply_op(t[0], a, b, out);
    }
    char *end = NULL;
    long long v = strtoll(t, &end, 10);
    if(!end || *end) return 0;
    *out = (int64_t)v;
    return 1;
}

int mad_eval_prefix(const char *expr, int64_t *result)
{
    char tok[64][24];
    int n = tokenize(expr, tok, 64);
    int index = 0;
    if(n <= 0 || !result || !eval_prefix_rec(tok, n, &index, result)) return 0;
    return index == n;
}

int mad_huffman_bit_length(const int *freq, int n, int *bit_length)
{
    if(!freq || !bit_length || n <= 0 || n > 64) return 0;
    int heap[128]; int size = 0;
    for(int i = 0; i < n; i++) if(freq[i] > 0) heap[size++] = freq[i];
    if(size == 0) return 0;
    if(size == 1) { *bit_length = heap[0]; return 1; }
    int total = 0;
    while(size > 1) {
        int i1 = 0;
        for(int i = 1; i < size; i++) if(heap[i] < heap[i1]) i1 = i;
        int a = heap[i1]; heap[i1] = heap[--size];
        int i2 = 0;
        for(int i = 1; i < size; i++) if(heap[i] < heap[i2]) i2 = i;
        int b = heap[i2]; heap[i2] = heap[--size];
        int c = a + b;
        total += c;
        heap[size++] = c;
    }
    *bit_length = total;
    return 1;
}
