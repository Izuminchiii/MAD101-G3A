#include <gint/display.h>
#include <gint/keyboard.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdarg.h>

#include "core.h"
#include "logic.h"
#include "quiz.h"

#define COLS 43
#define MAX_LINES 96
#define LINE_H 16

typedef struct {
    char line[MAX_LINES][COLS + 1];
    int count;
} TextPage;

static int app_running = 1;
static unsigned quiz_seed = 17;

static void page_init(TextPage *p)
{
    p->count = 0;
}

static void page_add(TextPage *p, const char *text)
{
    if(!p || !text || p->count >= MAX_LINES) return;
    size_t n = strlen(text);
    if(n == 0) {
        p->line[p->count++][0] = '\0';
        return;
    }
    size_t pos = 0;
    while(pos < n && p->count < MAX_LINES) {
        while(pos < n && text[pos] == ' ') pos++;
        size_t remaining = n - pos;
        size_t take = remaining < COLS ? remaining : COLS;
        if(take == COLS && pos + take < n) {
            size_t cut = take;
            while(cut > 0 && text[pos + cut] != ' ') cut--;
            if(cut > 8) take = cut;
        }
        memcpy(p->line[p->count], text + pos, take);
        p->line[p->count][take] = '\0';
        p->count++;
        pos += take;
    }
}

static void page_addf(TextPage *p, const char *fmt, ...)
{
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    page_add(p, buf);
}

static int show_page(const char *title, const TextPage *p)
{
    int top = 0;
    while(1) {
        dclear(C_WHITE);
        dtext(4, 3, C_BLACK, title ? title : "MAD101");
        dline(0, 20, DWIDTH - 1, 20, C_BLACK);
        int visible = 11;
        for(int i = 0; i < visible && top + i < p->count; i++) {
            dtext(4, 25 + i * LINE_H, C_BLACK, p->line[top + i]);
        }
        dline(0, DHEIGHT - 18, DWIDTH - 1, DHEIGHT - 18, C_BLACK);
        dtext(4, DHEIGHT - 15, C_BLACK, "UP/DOWN scroll  EXIT back");
        dupdate();
        int key = getkey().key;
        if(key == KEY_EXIT || key == KEY_MENU) return key;
        if(key == KEY_UP && top > 0) top--;
        if(key == KEY_DOWN && top + visible < p->count) top++;
        if(key == KEY_F5) { top -= visible; if(top < 0) top = 0; }
        if(key == KEY_F6) { top += visible; if(top + visible > p->count) top = p->count > visible ? p->count - visible : 0; }
    }
}

static void show_message(const char *title, const char *message)
{
    TextPage p; page_init(&p); page_add(&p, message); show_page(title, &p);
}

static int menu_select(const char *title, const char *const *items, int count)
{
    int selected = 0;
    int top = 0;
    const int visible = 9;
    while(1) {
        if(selected < top) top = selected;
        if(selected >= top + visible) top = selected - visible + 1;
        dclear(C_WHITE);
        dtext(4, 3, C_BLACK, title);
        dline(0, 20, DWIDTH - 1, 20, C_BLACK);
        for(int i = 0; i < visible && top + i < count; i++) {
            int idx = top + i;
            char buf[52];
            snprintf(buf, sizeof(buf), "%c %s", idx == selected ? '>' : ' ', items[idx]);
            dtext(8, 28 + i * 18, C_BLACK, buf);
        }
        dline(0, DHEIGHT - 18, DWIDTH - 1, DHEIGHT - 18, C_BLACK);
        dtext(4, DHEIGHT - 15, C_BLACK, "EXE select  EXIT back");
        dupdate();
        int key = getkey().key;
        if(key == KEY_UP && selected > 0) selected--;
        else if(key == KEY_DOWN && selected < count - 1) selected++;
        else if(key == KEY_EXE) return selected;
        else if(key == KEY_EXIT || key == KEY_MENU) return -1;
    }
}

static int64_t input_int64(const char *title, const char *prompt, int64_t initial, int *cancelled)
{
    char buf[28];
    snprintf(buf, sizeof(buf), "%lld", (long long)initial);
    int len = (int)strlen(buf);
    if(cancelled) *cancelled = 0;
    while(1) {
        dclear(C_WHITE);
        dtext(4, 3, C_BLACK, title);
        dline(0, 20, DWIDTH - 1, 20, C_BLACK);
        dtext(4, 38, C_BLACK, prompt);
        dtext(4, 70, C_BLACK, buf);
        dline(4, 88, DWIDTH - 8, 88, C_BLACK);
        dtext(4, 115, C_BLACK, "Digits, (-), DEL");
        dtext(4, 135, C_BLACK, "EXE accept  EXIT cancel");
        dupdate();
        int key = getkey().key;
        int digit = -1;
        if(key == KEY_0) digit = 0;
        else if(key == KEY_1) digit = 1;
        else if(key == KEY_2) digit = 2;
        else if(key == KEY_3) digit = 3;
        else if(key == KEY_4) digit = 4;
        else if(key == KEY_5) digit = 5;
        else if(key == KEY_6) digit = 6;
        else if(key == KEY_7) digit = 7;
        else if(key == KEY_8) digit = 8;
        else if(key == KEY_9) digit = 9;
        if(digit >= 0) {
            if(len < (int)sizeof(buf) - 1) {
                if(len == 1 && buf[0] == '0') len = 0;
                buf[len++] = (char)('0' + digit);
                buf[len] = '\0';
            }
        } else if(key == KEY_NEG || key == KEY_SUB) {
            if(len == 0) { buf[len++] = '-'; buf[len] = '\0'; }
            else if(buf[0] == '-') { memmove(buf, buf + 1, len); len--; }
            else if(len < (int)sizeof(buf) - 1) { memmove(buf + 1, buf, len + 1); buf[0] = '-'; len++; }
        } else if(key == KEY_DEL) {
            if(len > 0) buf[--len] = '\0';
        } else if(key == KEY_ACON) {
            len = 0; buf[0] = '\0';
        } else if(key == KEY_EXE) {
            if(len == 0 || (len == 1 && buf[0] == '-')) return 0;
            return strtoll(buf, NULL, 10);
        } else if(key == KEY_EXIT || key == KEY_MENU) {
            if(cancelled) *cancelled = 1;
            return 0;
        }
    }
}

static int input_int_list(const char *title, const char *label, int *out, int max_n)
{
    int cancel = 0;
    int n = (int)input_int64(title, "How many values?", max_n < 5 ? max_n : 5, &cancel);
    if(cancel || n < 1 || n > max_n) return 0;
    for(int i = 0; i < n; i++) {
        char prompt[48];
        snprintf(prompt, sizeof(prompt), "%s %d/%d", label, i + 1, n);
        out[i] = (int)input_int64(title, prompt, 0, &cancel);
        if(cancel) return 0;
    }
    return n;
}

static int logic_editor(char *out, int out_size, const char *title)
{
    int len = 0;
    out[0] = '\0';
    while(1) {
        dclear(C_WHITE);
        dtext(4, 3, C_BLACK, title);
        dline(0, 20, DWIDTH - 1, 20, C_BLACK);
        dtext(4, 30, C_BLACK, "1=P 2=Q 3=R 4=N 5=A 6=O");
        dtext(4, 48, C_BLACK, "7=X 8=I 9=B  ( ) supported");
        dtext(4, 78, C_BLACK, out);
        dline(4, 98, DWIDTH - 8, 98, C_BLACK);
        dtext(4, 125, C_BLACK, "N NOT, A AND, O OR, X XOR");
        dtext(4, 143, C_BLACK, "I implies, B iff");
        dtext(4, 175, C_BLACK, "EXE accept  DEL erase  EXIT back");
        dupdate();
        int key = getkey().key;
        char c = 0;
        if(key == KEY_1) c = 'P';
        else if(key == KEY_2) c = 'Q';
        else if(key == KEY_3) c = 'R';
        else if(key == KEY_4) c = 'N';
        else if(key == KEY_5) c = 'A';
        else if(key == KEY_6) c = 'O';
        else if(key == KEY_7) c = 'X';
        else if(key == KEY_8) c = 'I';
        else if(key == KEY_9) c = 'B';
        else if(key == KEY_LPAR) c = '(';
        else if(key == KEY_RPAR) c = ')';
        else if(key == KEY_0) c = '0';
        if(c && len < out_size - 1) { out[len++] = c; out[len] = '\0'; }
        else if(key == KEY_DEL && len > 0) out[--len] = '\0';
        else if(key == KEY_ACON) { len = 0; out[0] = '\0'; }
        else if(key == KEY_EXE && len > 0) return 1;
        else if(key == KEY_EXIT || key == KEY_MENU) return 0;
    }
}

static void logic_analyze(void)
{
    char expr[96];
    if(!logic_editor(expr, sizeof(expr), "Logic analyzer")) return;
    int vals[8], mask = 0;
    int rows = mad_logic_truth_table(expr, vals, 8, &mask);
    TextPage p; page_init(&p);
    page_addf(&p, "Expression: %s", expr);
    if(rows < 0) {
        page_add(&p, "Invalid expression. Check parentheses and operator order.");
        show_page("Logic result", &p); return;
    }
    int vars[3], nv = 0;
    if(mask & 1) vars[nv++] = 1;
    if(mask & 2) vars[nv++] = 2;
    if(mask & 4) vars[nv++] = 4;
    page_add(&p, "");
    page_add(&p, "Truth table (T=1,F=0):");
    for(int idx = 0; idx < rows; idx++) {
        int bits = rows - 1 - idx;
        int bitpos = nv - 1;
        char row[64] = "";
        for(int j = 0; j < nv; j++) {
            int v = (bits >> bitpos--) & 1;
            char part[12];
            snprintf(part, sizeof(part), "%c=%d ", vars[j] == 1 ? 'P' : vars[j] == 2 ? 'Q' : 'R', v);
            strncat(row, part, sizeof(row) - strlen(row) - 1);
        }
        char part[16]; snprintf(part, sizeof(part), "=> %d", vals[idx]);
        strncat(row, part, sizeof(row) - strlen(row) - 1);
        page_add(&p, row);
    }
    int cls = mad_logic_classify(expr);
    page_addf(&p, "Class: %s", cls == 2 ? "tautology" : cls == 0 ? "contradiction" : "contingency");
    show_page("Logic result", &p);
}

static void logic_equivalence(void)
{
    char a[96], b[96];
    if(!logic_editor(a, sizeof(a), "Expression A")) return;
    if(!logic_editor(b, sizeof(b), "Expression B")) return;
    int eq = mad_logic_equivalent(a, b);
    TextPage p; page_init(&p);
    page_addf(&p, "A: %s", a); page_addf(&p, "B: %s", b);
    page_add(&p, eq < 0 ? "Invalid expression." : eq ? "Equivalent for all P,Q,R." : "Not equivalent.");
    show_page("Equivalence", &p);
}

static void logic_symbols(void)
{
    TextPage p; page_init(&p);
    page_add(&p, "Calculator-safe logic notation:");
    page_add(&p, "P A Q      AND");
    page_add(&p, "P O Q      OR");
    page_add(&p, "P X Q      XOR");
    page_add(&p, "P I Q      P implies Q");
    page_add(&p, "P B Q      P iff Q");
    page_add(&p, "N(PAQ)     NOT(P AND Q)");
    page_add(&p, "Precedence: N > A > O/X > I > B");
    page_add(&p, "Use parentheses whenever unsure.");
    show_page("Logic symbols", &p);
}

static void logic_laws(void)
{
    TextPage p; page_init(&p);
    page_add(&p, "Identity:"); page_add(&p, "P A T = P; P O F = P");
    page_add(&p, "Domination:"); page_add(&p, "P O T = T; P A F = F");
    page_add(&p, "Idempotent:"); page_add(&p, "P O P = P; P A P = P");
    page_add(&p, "Double negation: N(NP)=P");
    page_add(&p, "Commutative: PAQ=QAP; POQ=QOP");
    page_add(&p, "Associative: (PAQ)AR=PA(QAR)");
    page_add(&p, "Distributive: PO(QAR)=(POQ)A(POR)");
    page_add(&p, "De Morgan: N(PAQ)=NP O NQ");
    page_add(&p, "De Morgan: N(POQ)=NP A NQ");
    page_add(&p, "Absorption: P O (P A Q)=P");
    page_add(&p, "Absorption: P A (P O Q)=P");
    page_add(&p, "Negation: P O NP=T; P A NP=F");
    page_add(&p, "Implication: P I Q = NP O Q");
    page_add(&p, "Contrapositive: P I Q = NQ I NP");
    show_page("Logical laws", &p);
}

static void menu_logic(void)
{
    const char *items[] = {"Analyze / truth table","Check equivalence","Symbol guide","Logical laws"};
    while(1) {
        int c = menu_select("1. LOGIC", items, 4);
        if(c < 0) return;
        if(c == 0) logic_analyze();
        else if(c == 1) logic_equivalence();
        else if(c == 2) logic_symbols();
        else logic_laws();
    }
}

static void number_gcd(void)
{
    int cancel = 0;
    int64_t a = input_int64("GCD / LCM", "a =", 899, &cancel); if(cancel) return;
    int64_t b = input_int64("GCD / LCM", "b =", 941, &cancel); if(cancel) return;
    int64_t g, x, y; mad_extended_gcd(a, b, &g, &x, &y);
    TextPage p; page_init(&p);
    page_addf(&p, "gcd(%lld,%lld) = %lld", (long long)a, (long long)b, (long long)g);
    page_addf(&p, "lcm = %lld", (long long)mad_lcm(a,b));
    page_addf(&p, "Bezout: %lld*a + %lld*b = %lld", (long long)x, (long long)y, (long long)g);
    show_page("GCD result", &p);
}

static void number_divmod(void)
{
    int cancel=0; int64_t a=input_int64("Floor div/mod","a =",-124,&cancel); if(cancel)return;
    int64_t b=input_int64("Floor div/mod","b =",15,&cancel); if(cancel||b==0)return;
    int64_t q,r; mad_floor_divmod(a,b,&q,&r);
    TextPage p; page_init(&p);
    page_addf(&p,"%lld div %lld = %lld",(long long)a,(long long)b,(long long)q);
    page_addf(&p,"%lld mod %lld = %lld",(long long)a,(long long)b,(long long)r);
    page_addf(&p,"Check: a=b*q+r");
    show_page("Div/mod result",&p);
}

static void number_prime(void)
{
    int cancel=0; int64_t n=input_int64("Prime / factors","n =",1025,&cancel); if(cancel)return;
    int64_t primes[24]; int powers[24]; int count=mad_prime_factorization(n,primes,powers,24);
    TextPage p; page_init(&p);
    page_addf(&p,"n = %lld",(long long)n);
    page_addf(&p,"Prime? %s",mad_is_prime(n)?"YES":"NO");
    if(count>0){ page_add(&p,"Factorization:"); for(int i=0;i<count;i++) page_addf(&p,"%lld ^ %d",(long long)primes[i],powers[i]); }
    page_addf(&p,"Number of positive divisors: %lld",(long long)mad_divisor_count(n));
    show_page("Prime result",&p);
}

static void number_base(void)
{
    int cancel=0; int64_t n=input_int64("Base conversion","Decimal value =",11232,&cancel); if(cancel)return;
    int base=(int)input_int64("Base conversion","Target base 2..16 =",2,&cancel); if(cancel)return;
    char out[80];
    if(!mad_to_base(n,base,out,sizeof(out))) { show_message("Base conversion","Invalid base or result too long."); return; }
    TextPage p; page_init(&p); page_addf(&p,"Decimal: %lld",(long long)n); page_addf(&p,"Base %d: %s",base,out); show_page("Base result",&p);
}

static void number_modpow(void)
{
    int cancel=0; int64_t a=input_int64("Modular power","base =",2,&cancel); if(cancel)return;
    int64_t e=input_int64("Modular power","exponent =",10,&cancel); if(cancel)return;
    int64_t m=input_int64("Modular power","modulus =",7,&cancel); if(cancel||m<=0||e<0)return;
    TextPage p;page_init(&p);page_addf(&p,"%lld^%lld mod %lld = %lld",(long long)a,(long long)e,(long long)m,(long long)mad_mod_pow(a,e,m));show_page("Mod result",&p);
}

static void number_lcg(void)
{
    int cancel=0; int64_t x0=input_int64("LCG","x0 =",1,&cancel);if(cancel)return;
    int64_t a=input_int64("LCG","a =",3,&cancel);if(cancel)return;
    int64_t c=input_int64("LCG","c =",4,&cancel);if(cancel)return;
    int64_t m=input_int64("LCG","m =",7,&cancel);if(cancel||m<=0)return;
    int n=(int)input_int64("LCG","Find x_n, n =",3,&cancel);if(cancel||n<0)return;
    TextPage p;page_init(&p);page_addf(&p,"x_%d = %lld",n,(long long)mad_lcg_term(x0,a,c,m,n));page_add(&p,"Rule: x(n+1)=(a*x(n)+c) mod m");show_page("LCG result",&p);
}

static void menu_number(void)
{
    const char *items[]={"GCD, LCM, Bezout","Floor div / mod","Prime and factors","Base conversion","Modular power","Linear congruential"};
    while(1){int c=menu_select("2. NUMBER THEORY",items,6);if(c<0)return;if(c==0)number_gcd();else if(c==1)number_divmod();else if(c==2)number_prime();else if(c==3)number_base();else if(c==4)number_modpow();else number_lcg();}
}

static void counting_ncr(void)
{
    int cancel=0;int n=(int)input_int64("P / C / factorial","n =",12,&cancel);if(cancel)return;int r=(int)input_int64("P / C / factorial","r =",3,&cancel);if(cancel)return;
    int ov=0;int64_t f=mad_factorial(n,&ov);TextPage p;page_init(&p);page_addf(&p,"n! = %s",ov?"overflow":"");if(!ov)page_addf(&p,"%lld",(long long)f);
    int64_t perm=mad_permutation(n,r,&ov);page_addf(&p,"P(n,r) = %s",ov?"overflow":"");if(!ov)page_addf(&p,"%lld",(long long)perm);
    int64_t comb=mad_combination(n,r,&ov);page_addf(&p,"C(n,r) = %s",ov?"overflow":"");if(!ov)page_addf(&p,"%lld",(long long)comb);show_page("Counting result",&p);
}

static void counting_functions(void)
{
    int cancel=0;int m=(int)input_int64("Function counts","Domain size m =",5,&cancel);if(cancel)return;int n=(int)input_int64("Function counts","Codomain size n =",4,&cancel);if(cancel)return;
    int ov=0;TextPage p;page_init(&p);int64_t all=mad_count_functions(m,n,&ov);page_addf(&p,"All functions n^m: %s",ov?"overflow":"");if(!ov)page_addf(&p,"%lld",(long long)all);
    int64_t inj=mad_count_injections(m,n,&ov);page_addf(&p,"Injective: %s",ov?"overflow":"");if(!ov)page_addf(&p,"%lld",(long long)inj);
    if(n<=12){int64_t sur=mad_count_surjections(m,n,&ov);page_addf(&p,"Surjective: %s",ov?"overflow":"");if(!ov)page_addf(&p,"%lld",(long long)sur);}else page_add(&p,"Surjective skipped (n>12).");show_page("Function counts",&p);
}

static void counting_inclusion(void)
{
    int cancel=0;int64_t N=input_int64("Inclusion-exclusion","Limit N =",200,&cancel);if(cancel)return;int64_t a=input_int64("Inclusion-exclusion","Divisor a =",5,&cancel);if(cancel)return;int64_t b=input_int64("Inclusion-exclusion","Divisor b =",7,&cancel);if(cancel)return;
    TextPage p;page_init(&p);page_addf(&p,"Count <=%lld divisible by %lld or %lld:",(long long)N,(long long)a,(long long)b);page_addf(&p,"%lld",(long long)mad_inclusion_two(N,a,b));show_page("Inclusion result",&p);
}

static void counting_sums(void)
{
    int cancel=0;int64_t n=input_int64("Common sums","n =",10,&cancel);if(cancel)return;TextPage p;page_init(&p);page_addf(&p,"1+...+n = %lld",(long long)(n*(n+1)/2));page_addf(&p,"First n evens = %lld",(long long)mad_sum_even(n));page_addf(&p,"First n odds = %lld",(long long)mad_sum_odd(n));page_addf(&p,"Power set size = 2^n (n<=62)");if(n>=0&&n<=62)page_addf(&p,"2^n = %lld",(long long)((int64_t)1<<n));show_page("Sum formulas",&p);
}

static void counting_recurrence(void)
{
    int cancel=0;int64_t f0=input_int64("2nd-order recurrence","f0 =",0,&cancel);if(cancel)return;int64_t f1=input_int64("2nd-order recurrence","f1 =",1,&cancel);if(cancel)return;int64_t a=input_int64("2nd-order recurrence","a*f(n-1), a =",1,&cancel);if(cancel)return;int64_t b=input_int64("2nd-order recurrence","b*f(n-2), b =",1,&cancel);if(cancel)return;int64_t c=input_int64("2nd-order recurrence","constant c =",0,&cancel);if(cancel)return;int n=(int)input_int64("2nd-order recurrence","Find f_n, n =",10,&cancel);if(cancel)return;int ov=0;int64_t ans=mad_linear_recurrence2(f0,f1,a,b,c,n,&ov);TextPage p;page_init(&p);page_addf(&p,"f(n)=a*f(n-1)+b*f(n-2)+c");page_addf(&p,"f_%d = %s",n,ov?"overflow":"");if(!ov)page_addf(&p,"%lld",(long long)ans);show_page("Recurrence result",&p);
}

static void menu_counting(void)
{
    const char *items[]={"Factorial, P, C","Function counts","Inclusion-exclusion","Common sums","2nd-order recurrence"};while(1){int c=menu_select("3. COUNTING / RECURRENCE",items,5);if(c<0)return;if(c==0)counting_ncr();else if(c==1)counting_functions();else if(c==2)counting_inclusion();else if(c==3)counting_sums();else counting_recurrence();}
}

static void graph_special(void)
{
    int cancel=0;int n=(int)input_int64("Special graphs","n =",7,&cancel);if(cancel)return;TextPage p;page_init(&p);page_addf(&p,"K_n: V=%d E=%lld degree=%d",n,(long long)mad_complete_graph_edges(n),n-1);page_addf(&p,"C_n: V=%d E=%d degree=2",n,n);page_addf(&p,"W_n(course): V=%d E=%d",n+1,2*n);page_addf(&p,"Q_n: V=%lld E=%lld",(long long)mad_hypercube_vertices(n),(long long)mad_hypercube_edges(n));show_page("Special graph formulas",&p);
}

static void graph_euler(void)
{
    int d[32];int n=input_int_list("Euler / graphical","Degree",d,32);if(n<=0)return;int type=mad_euler_type(d,n);TextPage p;page_init(&p);page_addf(&p,"Odd degree count determines Euler type.");page_addf(&p,"Euler: %s",type==2?"circuit (if connected)":type==1?"path only (if connected)":"none");page_addf(&p,"Simple graphical sequence? %s",mad_is_graphical(d,n)?"YES":"NO");show_page("Degree result",&p);
}

static void graph_mary(void)
{
    const char *modes[]={"Given internal vertices","Given leaves","Given total vertices"};int mode=menu_select("Full m-ary tree",modes,3);if(mode<0)return;int cancel=0;int m=(int)input_int64("Full m-ary tree","m =",3,&cancel);if(cancel)return;int a=(int)input_int64("Full m-ary tree",mode==0?"Internal i =":mode==1?"Leaves l =":"Vertices n =",mode==0?50:mode==1?101:151,&cancel);if(cancel)return;int i=0,l=0,n=0,ok=0;if(mode==0){i=a;ok=mad_full_mary_from_internal(m,i,&n,&l);}else if(mode==1){l=a;ok=mad_full_mary_from_leaves(m,l,&i,&n);}else{n=a;ok=mad_full_mary_from_vertices(m,n,&i,&l);}TextPage p;page_init(&p);if(!ok)page_add(&p,"Values do not form a full m-ary tree.");else{page_addf(&p,"m=%d internal=%d",m,i);page_addf(&p,"vertices=%d leaves=%d",n,l);page_add(&p,"n=m*i+1");page_add(&p,"l=(m-1)*i+1");}show_page("Tree result",&p);
}

static void graph_counts(void)
{
    int cancel=0;int n=(int)input_int64("Hamilton / spanning","n for K_n =",4,&cancel);if(cancel)return;int ov=0;TextPage p;page_init(&p);int64_t h=mad_hamilton_complete(n,&ov);page_addf(&p,"Hamilton circuits K_n: %s",ov?"overflow":"");if(!ov)page_addf(&p,"%lld",(long long)h);int64_t t=mad_spanning_complete(n,&ov);page_addf(&p,"Spanning trees K_n: %s",ov?"overflow":"");if(!ov)page_addf(&p,"%lld",(long long)t);page_add(&p,"Hamilton formula counts rotation and reversal as same.");show_page("Graph counts",&p);
}

static int input_graph(MadGraph *g, const char *title)
{
    int cancel=0;int n=(int)input_int64(title,"Number of vertices (<=12) =",5,&cancel);if(cancel||n<1||n>MAD_MAX_VERTICES)return 0;int m=(int)input_int64(title,"Number of edges =",6,&cancel);if(cancel||m<0||m>60)return 0;mad_graph_init(g,n);for(int i=0;i<m;i++){char pr[48];snprintf(pr,sizeof(pr),"Edge %d: u (1..n)",i+1);int u=(int)input_int64(title,pr,1,&cancel)-1;if(cancel)return 0;snprintf(pr,sizeof(pr),"Edge %d: v (1..n)",i+1);int v=(int)input_int64(title,pr,2,&cancel)-1;if(cancel)return 0;snprintf(pr,sizeof(pr),"Edge %d: weight",i+1);int w=(int)input_int64(title,pr,1,&cancel);if(cancel)return 0;if(!mad_graph_add_edge(g,u,v,w,1)){show_message(title,"Invalid edge. Start again.");return 0;}}return 1;
}

static void graph_dijkstra(void)
{
    MadGraph g;if(!input_graph(&g,"Dijkstra input"))return;int cancel=0;int s=(int)input_int64("Dijkstra","Source vertex =",1,&cancel)-1;if(cancel||s<0||s>=g.n)return;int dist[MAD_MAX_VERTICES],par[MAD_MAX_VERTICES];mad_dijkstra(&g,s,dist,par);TextPage p;page_init(&p);for(int i=0;i<g.n;i++){if(dist[i]>=MAD_INF)page_addf(&p,"v%d: unreachable",i+1);else page_addf(&p,"v%d: dist=%d parent=%d",i+1,dist[i],par[i]+1);}show_page("Dijkstra result",&p);
}

static void graph_prim(void)
{
    MadGraph g;if(!input_graph(&g,"Prim input"))return;int par[MAD_MAX_VERTICES],total=0;if(!mad_prim(&g,0,par,&total)){show_message("Prim","Graph is disconnected.");return;}TextPage p;page_init(&p);page_addf(&p,"MST total weight = %d",total);for(int i=1;i<g.n;i++)page_addf(&p,"edge %d-%d",par[i]+1,i+1);show_page("Prim result",&p);
}

static void graph_walks(void)
{
    int cancel=0;int n=(int)input_int64("Matrix walks","Matrix size n<=6 =",3,&cancel);if(cancel||n<1||n>6)return;int a[36];for(int i=0;i<n;i++)for(int j=0;j<n;j++){char pr[40];snprintf(pr,sizeof(pr),"A[%d,%d] =",i+1,j+1);a[i*n+j]=(int)input_int64("Matrix walks",pr,0,&cancel);if(cancel)return;}int k=(int)input_int64("Matrix walks","Walk length k =",3,&cancel);if(cancel)return;int from=(int)input_int64("Matrix walks","From vertex =",1,&cancel)-1;if(cancel)return;int to=(int)input_int64("Matrix walks","To vertex =",2,&cancel)-1;if(cancel)return;int64_t ans=0;TextPage p;page_init(&p);if(!mad_walk_count(a,n,k,from,to,&ans))page_add(&p,"Invalid input or overflow.");else{page_addf(&p,"Number of walks length %d",k);page_addf(&p,"from %d to %d = %lld",from+1,to+1,(long long)ans);}show_page("Walk count",&p);
}

static void menu_graph(void)
{
    const char *items[]={"Special graph formulas","Euler + graphical degrees","Full m-ary tree","Hamilton / spanning counts","Adjacency matrix walks","Dijkstra shortest paths","Prim minimum spanning tree"};while(1){int c=menu_select("4. GRAPHS / TREES",items,7);if(c<0)return;if(c==0)graph_special();else if(c==1)graph_euler();else if(c==2)graph_mary();else if(c==3)graph_counts();else if(c==4)graph_walks();else if(c==5)graph_dijkstra();else graph_prim();}
}

static void algo_insertion(void)
{
    int a[20];int n=input_int_list("Insertion sort","Value",a,20);if(n<=0)return;int cancel=0;int k=(int)input_int64("Insertion sort","Outer iterations =",n-1,&cancel);if(cancel)return;mad_insertion_sort_prefix(a,n,k);TextPage p;page_init(&p);page_add(&p,"Array after requested iterations:");char line[180]="";for(int i=0;i<n;i++){char t[20];snprintf(t,sizeof(t),"%d%s",a[i],i==n-1?"":" ");strncat(line,t,sizeof(line)-strlen(line)-1);}page_add(&p,line);show_page("Insertion result",&p);
}

static void algo_huffman(void)
{
    int f[32];int n=input_int_list("Huffman length","Frequency",f,32);if(n<=0)return;int bits=0;TextPage p;page_init(&p);if(mad_huffman_bit_length(f,n,&bits))page_addf(&p,"Encoded bit length = %d",bits);else page_add(&p,"Invalid frequencies.");page_add(&p,"Algorithm merges two smallest frequencies repeatedly.");show_page("Huffman result",&p);
}

static void algo_big_o(void)
{
    TextPage p;page_init(&p);page_add(&p,"Typical growth order (slow to fast):");page_add(&p,"1 < log n < n < n log n < n^2");page_add(&p,"< n^3 < 2^n < n!");page_add(&p,"");page_add(&p,"Rules:");page_add(&p,"Drop constants and lower-order terms.");page_add(&p,"Sum: keep the fastest growing term.");page_add(&p,"Product: multiply the classes.");page_add(&p,"Nested independent loops multiply.");page_add(&p,"Sequential blocks take the maximum.");page_add(&p,"Binary search O(log n).");page_add(&p,"Merge sort O(n log n).");page_add(&p,"Insertion sort worst O(n^2).");show_page("Big-O reference",&p);
}

static void algo_prefix_postfix(void)
{
    TextPage p;page_init(&p);page_add(&p,"Prefix: operator before operands.");page_add(&p,"Example: ((x+y)^3)-2");page_add(&p,"- ^ + x y 3 2");page_add(&p,"");page_add(&p,"Postfix: operator after operands.");page_add(&p,"Example: (x-y)^2+x(y+5)");page_add(&p,"x y - 2 ^ x y 5 + * +");page_add(&p,"");page_add(&p,"Numeric evaluator exists in core.c for projects that add a full text editor.");show_page("Prefix / postfix",&p);
}

static void menu_algorithms(void)
{
    const char *items[]={"Insertion sort trace","Huffman bit length","Big-O reference","Prefix/postfix guide"};while(1){int c=menu_select("5. ALGORITHMS",items,4);if(c<0)return;if(c==0)algo_insertion();else if(c==1)algo_huffman();else if(c==2)algo_big_o();else algo_prefix_postfix();}
}

static void formula_book(void)
{
    TextPage p;page_init(&p);
    page_add(&p,"SETS / COUNTING");page_add(&p,"|P(S)|=2^|S|");page_add(&p,"|A x B|=|A||B|");page_add(&p,"P(n,r)=n!/(n-r)!");page_add(&p,"C(n,r)=n!/[r!(n-r)!]");page_add(&p,"|A union B|=|A|+|B|-|A inter B|");
    page_add(&p,"");page_add(&p,"SUMS");page_add(&p,"1+...+n=n(n+1)/2");page_add(&p,"2+4+...+2n=n(n+1)");page_add(&p,"1+3+...+(2n-1)=n^2");
    page_add(&p,"");page_add(&p,"GRAPHS");page_add(&p,"K_n edges=n(n-1)/2");page_add(&p,"K_m,n edges=mn");page_add(&p,"W_n: V=n+1,E=2n (course)");page_add(&p,"Q_n: V=2^n,E=n2^(n-1)");page_add(&p,"Tree edges=V-1");
    page_add(&p,"");page_add(&p,"FULL m-ARY");page_add(&p,"V=m*i+1");page_add(&p,"L=(m-1)i+1");
    page_add(&p,"");page_add(&p,"EULER");page_add(&p,"0 odd degrees: circuit");page_add(&p,"2 odd degrees: path only");
    page_add(&p,"");page_add(&p,"HAMILTON / SPANNING");page_add(&p,"K_n Hamilton=(n-1)!/2");page_add(&p,"K_n trees=n^(n-2)");page_add(&p,"K_m,n trees=m^(n-1)n^(m-1)");
    page_add(&p,"");page_add(&p,"COMPOUND INTEREST");page_add(&p,"A=P(1+r/k)^(kt)");
    show_page("6. FORMULA BOOK",&p);
}

static int quiz_category_match(const char *cat, const char *filter)
{
    return !filter || !*filter || strcmp(cat,filter)==0;
}

static int quiz_pick(const char *filter, int random_mode, int current)
{
    int candidates[128],n=0;for(int i=0;i<MAD_QUIZ_COUNT&&n<128;i++)if(quiz_category_match(MAD_QUIZ[i].category,filter))candidates[n++]=i;if(n==0)return -1;if(random_mode){quiz_seed=quiz_seed*1103515245u+12345u;return candidates[(quiz_seed>>16)%n];}return candidates[current%n];
}

static void quiz_run(const char *filter, int random_mode)
{
    int pos=0,score=0,asked=0;
    while(1){int idx=quiz_pick(filter,random_mode,pos);if(idx<0)return;const MadQuizQuestion *q=&MAD_QUIZ[idx];dclear(C_WHITE);char head[64];snprintf(head,sizeof(head),"QUIZ %s  score %d/%d",q->category,score,asked);dtext(4,3,C_BLACK,head);dline(0,20,DWIDTH-1,20,C_BLACK);
        TextPage wrapped;page_init(&wrapped);page_add(&wrapped,q->question);int y=26;for(int i=0;i<wrapped.count&&i<4;i++){dtext(4,y,C_BLACK,wrapped.line[i]);y+=15;}y+=2;for(int i=0;i<4;i++){char line[64];snprintf(line,sizeof(line),"F%d. %s",i+1,q->choice[i]);dtext(8,y,C_BLACK,line);y+=19;}dtext(4,DHEIGHT-15,C_BLACK,"F1-F4 answer  EXIT back");dupdate();int key=getkey().key;if(key==KEY_EXIT||key==KEY_MENU)return;int ans=-1;if(key==KEY_F1)ans=0;else if(key==KEY_F2)ans=1;else if(key==KEY_F3)ans=2;else if(key==KEY_F4)ans=3;if(ans<0)continue;asked++;if(ans==q->answer)score++;TextPage p;page_init(&p);page_addf(&p,"Your answer: %c",'A'+ans);page_addf(&p,"Correct: %c",'A'+q->answer);page_add(&p,ans==q->answer?"CORRECT":"WRONG");page_add(&p,"");page_add(&p,q->explain);show_page("Quiz explanation",&p);pos++;}
}

static void quiz_menu(void)
{
    const char *items[]={"Random all categories","Logic","Sets","Number","Algorithm","Counting","Recurrence","Graph","Tree"};const char *filters[]={"","Logic","Sets","Number","Algorithm","Counting","Recurrence","Graph","Tree"};while(1){int c=menu_select("7. QUIZ BANK (106 unique)",items,9);if(c<0)return;quiz_run(filters[c],1);}
}

static void about(void)
{
    TextPage p;page_init(&p);page_add(&p,"MAD101 Toolkit for Casio fx-CG50 / AU");page_add(&p,"Build-ready fxSDK/gint C project.");page_add(&p,"Modules: logic, sets references, number theory, counting, recurrence, graphs, trees, algorithms and quiz bank.");page_addf(&p,"Question bank: %d deduplicated practice questions.",MAD_QUIZ_COUNT);page_add(&p,"Question text is paraphrased from the user's screenshots and course materials.");page_add(&p,"Use only where calculator add-ins are permitted.");show_page("About",&p);
}

int main(void)
{
    const char *items[]={"Logic","Number theory","Counting / recurrence","Graphs / trees","Algorithms","Formula book","Quiz bank","About","Exit"};
    while(app_running){int c=menu_select("MAD101 TOOLKIT - fx-CG50",items,9);if(c<0||c==8)break;if(c==0)menu_logic();else if(c==1)menu_number();else if(c==2)menu_counting();else if(c==3)menu_graph();else if(c==4)menu_algorithms();else if(c==5)formula_book();else if(c==6)quiz_menu();else about();}
    return 1;
}
