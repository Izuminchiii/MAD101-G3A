#ifndef MAD101_QUIZ_H
#define MAD101_QUIZ_H

typedef struct {
    const char *category;
    const char *question;
    const char *choice[4];
    unsigned char answer;
    const char *explain;
} MadQuizQuestion;

extern const MadQuizQuestion MAD_QUIZ[];
extern const int MAD_QUIZ_COUNT;

#endif
