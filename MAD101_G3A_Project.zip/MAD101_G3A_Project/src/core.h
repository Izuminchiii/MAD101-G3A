#ifndef MAD101_CORE_H
#define MAD101_CORE_H

#include <stdint.h>
#include <stddef.h>

#define MAD_MAX_VERTICES 12
#define MAD_INF 0x3fffffff

typedef struct {
    int n;
    int w[MAD_MAX_VERTICES][MAD_MAX_VERTICES];
} MadGraph;

typedef struct {
    int valid;
    int64_t value;
} MadIntResult;

int64_t mad_abs64(int64_t x);
int64_t mad_gcd(int64_t a, int64_t b);
int64_t mad_lcm(int64_t a, int64_t b);
void mad_extended_gcd(int64_t a, int64_t b, int64_t *g, int64_t *x, int64_t *y);
void mad_floor_divmod(int64_t a, int64_t b, int64_t *q, int64_t *r);
int mad_is_prime(int64_t n);
int mad_prime_factorization(int64_t n, int64_t *primes, int *powers, int max_terms);
int64_t mad_divisor_count(int64_t n);
int64_t mad_mod_pow(int64_t base, int64_t exp, int64_t mod);
int mad_to_base(int64_t value, int base, char *out, size_t out_size);
MadIntResult mad_from_base(const char *text, int base);

int64_t mad_factorial(int n, int *overflow);
int64_t mad_permutation(int n, int r, int *overflow);
int64_t mad_combination(int n, int r, int *overflow);
int64_t mad_count_functions(int domain_size, int codomain_size, int *overflow);
int64_t mad_count_injections(int domain_size, int codomain_size, int *overflow);
int64_t mad_count_surjections(int domain_size, int codomain_size, int *overflow);
int64_t mad_inclusion_two(int64_t limit, int64_t a, int64_t b);
int64_t mad_sum_even(int64_t n);
int64_t mad_sum_odd(int64_t n);
double mad_compound_interest(double principal, double rate_percent, int years, int compounds_per_year);

int64_t mad_lcg_term(int64_t x0, int64_t a, int64_t c, int64_t m, int n);
int64_t mad_linear_recurrence2(int64_t f0, int64_t f1, int64_t a, int64_t b, int64_t c, int n, int *overflow);
int64_t mad_recurrence_square(int64_t f0, int64_t a, int64_t b, int n, int *overflow);

int mad_full_mary_from_internal(int m, int internal, int *vertices, int *leaves);
int mad_full_mary_from_leaves(int m, int leaves, int *internal, int *vertices);
int mad_full_mary_from_vertices(int m, int vertices, int *internal, int *leaves);
int64_t mad_complete_graph_edges(int n);
int64_t mad_complete_bipartite_edges(int m, int n);
int64_t mad_hypercube_vertices(int n);
int64_t mad_hypercube_edges(int n);
int64_t mad_hamilton_complete(int n, int *overflow);
int64_t mad_spanning_complete(int n, int *overflow);
int64_t mad_spanning_complete_bipartite(int m, int n, int *overflow);
int mad_euler_type(const int *degrees, int n); /* 2=circuit,1=path,0=none */
int mad_is_graphical(const int *degrees, int n);

void mad_graph_init(MadGraph *g, int n);
int mad_graph_add_edge(MadGraph *g, int u, int v, int weight, int undirected);
int mad_dijkstra(const MadGraph *g, int source, int *dist, int *parent);
int mad_prim(const MadGraph *g, int start, int *parent, int *total_weight);
int mad_walk_count(const int *matrix, int n, int length, int from, int to, int64_t *answer);

int mad_binary_search_comparisons(const int *sorted, int n, int target);
void mad_insertion_sort_prefix(int *a, int n, int outer_iterations);
int mad_eval_postfix(const char *expr, int64_t *result);
int mad_eval_prefix(const char *expr, int64_t *result);
int mad_huffman_bit_length(const int *freq, int n, int *bit_length);

#endif
