#ifndef MAD101_LOGIC_H
#define MAD101_LOGIC_H

#include <stddef.h>

typedef struct {
    int valid;
    int value;
    int used_mask; /* P=1,Q=2,R=4 */
    int error_pos;
} MadLogicResult;

MadLogicResult mad_logic_eval(const char *expr, int p, int q, int r);
int mad_logic_used_mask(const char *expr);
int mad_logic_truth_table(const char *expr, int *values, int max_values, int *used_mask);
int mad_logic_classify(const char *expr); /* 2 tautology, 1 contingency, 0 contradiction, -1 invalid */
int mad_logic_equivalent(const char *a, const char *b); /* 1 eq, 0 not eq, -1 invalid */

#endif
