#include "logic.h"

#include <ctype.h>
#include <string.h>

typedef struct {
    const char *s;
    int pos;
    int p, q, r;
    int used;
    int error;
} Parser;

static void skip_ws(Parser *ps)
{
    while(ps->s[ps->pos] && isspace((unsigned char)ps->s[ps->pos])) ps->pos++;
}

static int peek(Parser *ps)
{
    skip_ws(ps);
    return toupper((unsigned char)ps->s[ps->pos]);
}

static int take(Parser *ps)
{
    int c = peek(ps);
    if(c) ps->pos++;
    return c;
}

static int parse_equiv(Parser *ps);

static int parse_unary(Parser *ps)
{
    int c = peek(ps);
    if(c == 'N' || c == '!') {
        take(ps);
        return !parse_unary(ps);
    }
    if(c == '(') {
        take(ps);
        int v = parse_equiv(ps);
        if(peek(ps) != ')') { ps->error = 1; return 0; }
        take(ps);
        return v;
    }
    if(c == 'P') { take(ps); ps->used |= 1; return ps->p != 0; }
    if(c == 'Q') { take(ps); ps->used |= 2; return ps->q != 0; }
    if(c == 'R') { take(ps); ps->used |= 4; return ps->r != 0; }
    if(c == 'T' || c == '1') { take(ps); return 1; }
    if(c == 'F' || c == '0') { take(ps); return 0; }
    ps->error = 1;
    return 0;
}

static int parse_and(Parser *ps)
{
    int v = parse_unary(ps);
    while(!ps->error) {
        int c = peek(ps);
        if(c != 'A' && c != '&') break;
        take(ps);
        int rhs = parse_unary(ps);
        v = v && rhs;
    }
    return v;
}

static int parse_or_xor(Parser *ps)
{
    int v = parse_and(ps);
    while(!ps->error) {
        int c = peek(ps);
        if(c != 'O' && c != 'X' && c != '|') break;
        take(ps);
        int rhs = parse_and(ps);
        if(c == 'X') v = (!!v) ^ (!!rhs);
        else v = v || rhs;
    }
    return v;
}

static int parse_impl(Parser *ps)
{
    int lhs = parse_or_xor(ps);
    if(!ps->error) {
        int c = peek(ps);
        if(c == 'I' || c == '>') {
            take(ps);
            int rhs = parse_impl(ps);
            return (!lhs) || rhs;
        }
    }
    return lhs;
}

static int parse_equiv(Parser *ps)
{
    int v = parse_impl(ps);
    while(!ps->error) {
        int c = peek(ps);
        if(c != 'B' && c != '=') break;
        take(ps);
        int rhs = parse_impl(ps);
        v = (!!v) == (!!rhs);
    }
    return v;
}

MadLogicResult mad_logic_eval(const char *expr, int p, int q, int r)
{
    MadLogicResult out = {0, 0, 0, 0};
    if(!expr) return out;
    Parser ps = {expr, 0, p, q, r, 0, 0};
    int value = parse_equiv(&ps);
    skip_ws(&ps);
    if(ps.error || ps.s[ps.pos] != '\0') {
        out.error_pos = ps.pos;
        return out;
    }
    out.valid = 1;
    out.value = !!value;
    out.used_mask = ps.used;
    out.error_pos = -1;
    return out;
}

int mad_logic_used_mask(const char *expr)
{
    MadLogicResult r = mad_logic_eval(expr, 0, 0, 0);
    return r.valid ? r.used_mask : -1;
}

int mad_logic_truth_table(const char *expr, int *values, int max_values, int *used_mask)
{
    int mask = mad_logic_used_mask(expr);
    if(mask < 0) return -1;
    int vars = ((mask & 1) != 0) + ((mask & 2) != 0) + ((mask & 4) != 0);
    int rows = 1 << vars;
    if(!values || max_values < rows) return -1;
    int index = 0;
    for(int bits = rows - 1; bits >= 0; bits--) {
        int bitpos = vars - 1;
        int p = 0, q = 0, r = 0;
        if(mask & 1) p = (bits >> bitpos--) & 1;
        if(mask & 2) q = (bits >> bitpos--) & 1;
        if(mask & 4) r = (bits >> bitpos--) & 1;
        MadLogicResult ev = mad_logic_eval(expr, p, q, r);
        if(!ev.valid) return -1;
        values[index++] = ev.value;
    }
    if(used_mask) *used_mask = mask;
    return rows;
}

int mad_logic_classify(const char *expr)
{
    int vals[8], mask = 0;
    int rows = mad_logic_truth_table(expr, vals, 8, &mask);
    (void)mask;
    if(rows < 0) return -1;
    int any_true = 0, any_false = 0;
    for(int i = 0; i < rows; i++) {
        any_true |= vals[i];
        any_false |= !vals[i];
    }
    if(any_true && !any_false) return 2;
    if(!any_true && any_false) return 0;
    return 1;
}

int mad_logic_equivalent(const char *a, const char *b)
{
    int ma = mad_logic_used_mask(a);
    int mb = mad_logic_used_mask(b);
    if(ma < 0 || mb < 0) return -1;
    int mask = ma | mb;
    for(int p = 0; p <= 1; p++) for(int q = 0; q <= 1; q++) for(int r = 0; r <= 1; r++) {
        MadLogicResult x = mad_logic_eval(a, p, q, r);
        MadLogicResult y = mad_logic_eval(b, p, q, r);
        if(!x.valid || !y.valid) return -1;
        if(x.value != y.value) return 0;
        if(mask == 0) break;
    }
    return 1;
}
