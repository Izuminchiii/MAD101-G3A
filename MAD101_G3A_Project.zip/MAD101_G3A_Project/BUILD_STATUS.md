# Build status

## Verified in this package

- `src/core.c` and `src/logic.c` compile with GCC 14 in C11 mode.
- Unit tests pass.
- `src/main.c` passes a host syntax check against local gint API stubs.
- The question generator produces 106 unique questions.
- Icon files are valid 92x64 PNG images.

## Not verified in this environment

- Final SuperH linking.
- Execution on physical fx-CG50 / fx-CG50 AU hardware.
- The experimental GitHub Actions toolchain installation.

A real `.g3a` must be produced by `fxsdk build-cg` with `sh-elf-gcc`, fxlibc and gint installed.
