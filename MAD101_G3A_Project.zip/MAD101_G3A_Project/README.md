# MAD101 Toolkit for Casio fx-CG50 / fx-CG50 AU

A build-ready C project for the fxSDK + gint toolchain. The planned output is `MAD101.g3a`.

## Current status

- Core algorithms compile and pass host-side tests.
- The calculator UI is implemented with gint display/keyboard APIs.
- 106 unique practice questions are embedded.
- Questions were paraphrased from the screenshots and course materials supplied in the conversation, then exact duplicates were removed.
- This package does **not** contain a precompiled `.g3a` binary because the current execution environment does not have the SuperH `sh-elf-gcc` cross-compiler installed.

## Main modules

1. **Logic**
   - Calculator-safe symbols: `N A O X I B`
   - Infix parser with parentheses and precedence
   - Truth tables for P, Q, R
   - Tautology / contradiction / contingency
   - Logical equivalence checker
   - Logical laws reference

2. **Number theory**
   - GCD, LCM, extended Euclid / Bezout coefficients
   - Floor `div` and `mod`, including negative integers
   - Prime test, factorization and divisor count
   - Base conversion from decimal to bases 2..16
   - Modular exponentiation
   - Linear congruential generator

3. **Counting and recurrence**
   - Factorial, permutation and combination
   - Counts of all / injective / surjective functions
   - Inclusion-exclusion for divisibility
   - Common sum formulas
   - Generic second-order recurrence

4. **Graphs and trees**
   - Formulas for `K_n`, `K_m,n`, `C_n`, `W_n`, `Q_n`
   - Euler path/circuit test from degrees
   - Havel-Hakimi graphical-sequence test
   - Full m-ary tree solver
   - Hamilton circuits and spanning-tree formulas
   - Walk count using powers of an adjacency matrix
   - Dijkstra shortest paths
   - Prim minimum spanning tree

5. **Algorithms**
   - Partial insertion-sort trace
   - Huffman encoded bit length
   - Big-O reference
   - Prefix/postfix guide

6. **Quiz bank**
   - 106 deduplicated questions
   - Categories: Logic, Sets, Number, Algorithm, Counting, Recurrence, Graph, Tree
   - F1-F4 answer keys and short explanations

## Logic input on the calculator

| Key | Token | Meaning |
|---|---:|---|
| `1` | `P` | proposition P |
| `2` | `Q` | proposition Q |
| `3` | `R` | proposition R |
| `4` | `N` | NOT |
| `5` | `A` | AND |
| `6` | `O` | OR |
| `7` | `X` | XOR |
| `8` | `I` | implication |
| `9` | `B` | biconditional |

Precedence: `N > A > O/X > I > B`. Parentheses are supported.

Examples:

```text
N(PAQ)
(PIQ)AR
(PAQ)I(PIQ)
```

## Host-side test

```bash
make -f Makefile.host test
make -f Makefile.host syntax
```

The syntax target uses small local stubs for gint only to catch ordinary C errors. It does not replace a real fxSDK build.

## Build the `.g3a`

After installing fxSDK, the SuperH cross-compiler, fxlibc and gint:

```bash
fxsdk build-cg
find . -name 'MAD101.g3a'
```

Copy `MAD101.g3a` to the root of the calculator storage drive, safely eject, then open `MAD101` from the main menu.

## GitHub Actions

`.github/workflows/build-g3a.yml` contains:

- a fast host-test job;
- an experimental fxSDK installation and `.g3a` build job;
- upload of the generated `.g3a` as a workflow artifact.

The first toolchain build can be slow. Caching is enabled for later runs.

## Project structure

```text
CMakeLists.txt
Makefile.host
assets-cg/
  icon-uns.png
  icon-sel.png
src/
  main.c
  core.c / core.h
  logic.c / logic.h
  quiz.h
  quiz_data.c
data/
  question_bank.tsv
tools/
  generate_quiz.py
  install_fxsdk.sh
tests/
  test_core.c
  stubs/gint/
.github/workflows/
  build-g3a.yml
```

## Limits

- Matrix walk calculations are limited to 6x6 to avoid excessive RAM and overflow.
- Graph input is limited to 12 vertices.
- Integer combinatorics use signed 64-bit values and report overflow.
- Dijkstra requires nonnegative weights.
- Euler results assume the relevant non-isolated part of the graph is connected.
- General Hamiltonicity is not automatically decidable by a simple formula; the app only provides formulas for special graphs.
